
  # Mood & Med Tracker App

  This is a code bundle for Mood & Med Tracker App. The original project is available at https://www.figma.com/design/ScigRgUnPhxDn2592113Jo/Mood---Med-Tracker-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  