export default {
p1e9a0270: "M6.9282 0L13.8564 7.6H0L6.9282 0Z",
}
